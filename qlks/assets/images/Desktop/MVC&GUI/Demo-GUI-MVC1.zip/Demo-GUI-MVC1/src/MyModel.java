
public class MyModel {
	//properties
	
	
	//methods
	public int getSum(int firstNumber, int secondNumber) {
		return firstNumber + secondNumber;
	}

}
