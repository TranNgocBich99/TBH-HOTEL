package ui;

public class MyTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyWindow aWindow = new MyWindow();
		aWindow.setVisible(true);
	}

}
